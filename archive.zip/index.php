<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Лабораторная-1</title>
</head>
<body>
<ul>
    <li><a href="./1.php">Метод Цезаря(шифрование)</a></li>
    <li><a href="./11.php">Метод Цезаря(дешифрование)</a></li>
    <li><a href="./2.php">Квадрат Полибия(шифрование)</a></li>
    <li><a href="./3.php">Метод Виженера(шифрование)</a></li>
    <li><a href="./33.php">Метод Виженера(дешифрование)</a></li>
</ul>
</body>
</html>